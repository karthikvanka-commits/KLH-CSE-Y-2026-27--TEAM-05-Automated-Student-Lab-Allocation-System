import java.util.ArrayList;
import java.util.List;

public class BipartiteGraph {

    private List<Student> students;
    private List<LabSlot> labSlots;

    private List<List<Integer>> adjacencyList;

    public BipartiteGraph(List<Student> students, List<LabSlot> labSlots) {

        this.students = students;
        this.labSlots = labSlots;

        adjacencyList = new ArrayList<>();

        for (int i = 0; i < students.size(); i++) {
            adjacencyList.add(new ArrayList<>());
        }
    }

    public void addEdge(int studentIndex, int labSlotIndex) {

        adjacencyList.get(studentIndex).add(labSlotIndex);
    }

    public List<Integer> getConnections(int studentIndex) {

        return adjacencyList.get(studentIndex);
    }

    public List<Student> getStudents() {

        return students;
    }

    public List<LabSlot> getLabSlots() {

        return labSlots;
    }

    public void displayGraph() {

        System.out.println("\n===== BIPARTITE GRAPH =====");

        for (int i = 0; i < students.size(); i++) {

            System.out.print(
                    students.get(i).getStudentId() + " -> "
            );

            for (int labSlotIndex : adjacencyList.get(i)) {

                System.out.print(
                        labSlots.get(labSlotIndex).getLabId()
                        + "-"
                        + labSlots.get(labSlotIndex).getSlot()
                        + "  "
                );
            }

            System.out.println();
        }
    }
}