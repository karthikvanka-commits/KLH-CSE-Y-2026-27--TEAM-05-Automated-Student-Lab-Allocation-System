public class LabSlot {

    private String labId;
    private String labName;
    private String slot;
    private int capacity;

    public LabSlot(String labId, String labName, String slot, int capacity) {
        this.labId = labId;
        this.labName = labName;
        this.slot = slot;
        this.capacity = capacity;
    }

    public String getLabId() {
        return labId;
    }

    public String getLabName() {
        return labName;
    }

    public String getSlot() {
        return slot;
    }

    public int getCapacity() {
        return capacity;
    }

    @Override
    public String toString() {
        return labId + " | " + labName + " | " +
               slot + " | Capacity: " + capacity;
    }
}