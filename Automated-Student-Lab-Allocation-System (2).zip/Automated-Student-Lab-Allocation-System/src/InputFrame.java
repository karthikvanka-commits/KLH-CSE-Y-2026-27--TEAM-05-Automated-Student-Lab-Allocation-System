import javax.swing.*;
import java.awt.*;
import java.util.List;

public class InputFrame extends JFrame {

    private MainFrame mainFrame;

    private JTextField countField;

    public InputFrame(
            MainFrame mainFrame) {

        this.mainFrame =
                mainFrame;

        setTitle(
                "Student Input"
        );

        setSize(
                600,
                420
        );

        setLocationRelativeTo(
                mainFrame
        );

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        createInterface();
    }

    private void createInterface() {

        JPanel mainPanel =
                new JPanel(
                        new BorderLayout(
                                20,
                                20
                        )
                );

        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        25,
                        30,
                        25,
                        30
                )
        );

        // ==========================================
        // TITLE
        // ==========================================

        JLabel title =
                new JLabel(
                        "STUDENT INPUT",
                        SwingConstants.CENTER
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        24
                )
        );

        mainPanel.add(
                title,
                BorderLayout.NORTH
        );

        // ==========================================
        // OPTIONS
        // ==========================================

        JPanel centerPanel =
                new JPanel(
                        new GridLayout(
                                2,
                                1,
                                15,
                                15
                        )
                );

        // ==========================================
        // RANDOM DATA
        // ==========================================

        JPanel randomPanel =
                new JPanel(
                        new GridLayout(
                                2,
                                2,
                                10,
                                10
                        )
                );

        randomPanel.setBorder(
                BorderFactory.createTitledBorder(
                        "Generate Random Students"
                )
        );

        randomPanel.add(
                new JLabel(
                        "Number of Students:"
                )
        );

        countField =
                new JTextField("20");

        randomPanel.add(
                countField
        );

        JButton randomButton =
                new JButton(
                        "Generate Random Students"
                );

        randomPanel.add(
                randomButton
        );

        randomPanel.add(
                new JLabel(
                        "Generated data replaces current students."
                )
        );

        centerPanel.add(
                randomPanel
        );

        // ==========================================
        // MANUAL DATA
        // ==========================================

        JPanel manualPanel =
                new JPanel(
                        new BorderLayout(
                                10,
                                10
                        )
                );

        manualPanel.setBorder(
                BorderFactory.createTitledBorder(
                        "Manual Input"
                )
        );

        JLabel manualText =
                new JLabel(
                        "<html>"
                        + "Add multiple students manually "
                        + "and review them before allocation."
                        + "</html>"
                );

        JButton manualButton =
                new JButton(
                        "Enter Students Manually"
                );

        manualPanel.add(
                manualText,
                BorderLayout.CENTER
        );

        manualPanel.add(
                manualButton,
                BorderLayout.SOUTH
        );

        centerPanel.add(
                manualPanel
        );

        mainPanel.add(
                centerPanel,
                BorderLayout.CENTER
        );

        // ==========================================
        // RANDOM ACTION
        // ==========================================

        randomButton.addActionListener(
                e -> generateRandomStudents()
        );

        // ==========================================
        // MANUAL ACTION
        // ==========================================

        manualButton.addActionListener(
                e -> {

                    ManualStudentFrame frame =
                            new ManualStudentFrame(
                                    mainFrame
                            );

                    frame.setVisible(
                            true
                    );
                }
        );

        setContentPane(
                mainPanel
        );
    }

    // ==========================================
    // RANDOM GENERATION
    // ==========================================

    private void generateRandomStudents() {

        try {

            int count =
                    Integer.parseInt(
                            countField
                                    .getText()
                                    .trim()
                    );

            if (count <= 0) {

                JOptionPane.showMessageDialog(
                        this,
                        "Enter a number greater than 0."
                );

                return;
            }

            List<Student> generated =
                    RandomStudentGenerator
                            .generateStudents(
                                    count
                            );

            mainFrame.setStudents(
                    generated
            );

            JOptionPane.showMessageDialog(
                    this,

                    count
                    + " random students generated successfully.\n\n"
                    + "Click 'Run Allocation' on the dashboard "
                    + "to perform Maximum Bipartite Matching.",

                    "Random Data Generated",

                    JOptionPane.INFORMATION_MESSAGE
            );

            dispose();

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter a valid number."
            );
        }
    }
}