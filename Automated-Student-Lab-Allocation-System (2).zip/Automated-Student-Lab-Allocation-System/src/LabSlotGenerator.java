import java.util.ArrayList;
import java.util.List;

public class LabSlotGenerator {

    public static List<LabSlot> generateLabSlots(List<Lab> labs) {

        List<LabSlot> labSlots = new ArrayList<>();

        for (Lab lab : labs) {
            
            String[] slots = lab.getAvailableSlots().split(";");

            for (String slot : slots) {

                LabSlot labSlot = new LabSlot(
                        lab.getLabId(),
                        lab.getLabName(),
                        slot.trim(),
                        lab.getCapacity()
                );

                labSlots.add(labSlot);
            }
        }

        return labSlots;
    }
}